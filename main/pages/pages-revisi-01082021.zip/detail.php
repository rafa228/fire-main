Bagikan Pengetahuan ini ke:
<?php echo $data; ?>
<ol>
	<li><a href="google.com">Whatsapp</a></li>
	<li>Facebook</li>
</ol>