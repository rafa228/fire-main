                  <td>
                      <a  id="btn1" type="button" class="btn btn-sm btn-success" href="#" data-toggle="modal" data-target="#modalApprove<?php echo $permohonan_detail['id_permohonan']; ?>">
                              <i class="fas fa-check"></i> Setujui
                      </a>
                      <a  id="btn1" type="button" class="btn btn-sm btn-danger" href="#" data-toggle="modal" data-target="#modalDecline<?php echo $permohonan_detail['id_permohonan']; ?>">
                              <i class="fas fa-times"></i> Tolak
                    </td>